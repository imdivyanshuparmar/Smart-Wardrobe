import itertools
import urllib.parse


# ---------------- COLOR RULES ---------------- #

SKIN_TONE_PALETTES = {

    "warm": ["olive", "mustard", "cream", "brown", "maroon"],
    "cool": ["navy", "blue", "purple", "grey", "emerald"],
    "neutral": ["white", "beige", "navy", "teal", "grey"]

}


# ---------------- ITEM TYPES ---------------- #

ITEM_TYPES = ["shirt", "tshirt", "chinos", "jeans", "sneakers"]


# ---------------- GET CURRENT COLORS ---------------- #

def wardrobe_colors(wardrobe):

    colors = set()

    for category in wardrobe:
        for item in wardrobe[category]:
            colors.add(item["color"])

    return colors


# ---------------- GENERATE VIRTUAL ITEMS ---------------- #

def generate_candidate_items(user):

    palette = SKIN_TONE_PALETTES.get(user["skinTone"], [])

    candidates = []

    for color in palette:
        for item in ITEM_TYPES:

            candidates.append({
                "type": item,
                "color": color
            })

    return candidates


# ---------------- COUNT POSSIBLE OUTFITS ---------------- #

def count_outfits(tops, bottoms, shoes):

    return len(list(itertools.product(tops, bottoms, shoes)))


# ---------------- SIMULATE ITEM IMPACT ---------------- #

def simulate_item_gain(item, wardrobe):

    tops = wardrobe["tops"].copy()
    bottoms = wardrobe["bottoms"].copy()
    shoes = wardrobe["shoes"].copy()

    if item["type"] in ["shirt", "tshirt"]:
        tops.append(item)

    elif item["type"] in ["chinos", "jeans"]:
        bottoms.append(item)

    else:
        shoes.append(item)

    return count_outfits(tops, bottoms, shoes)


# ---------------- ECOMMERCE LINKS ---------------- #

def ecommerce_links(item):

    query = f"{item['color']} {item['type']} men"

    encoded = urllib.parse.quote(query)

    return {
        "amazon": f"https://www.amazon.in/s?k={encoded}",
        "flipkart": f"https://www.flipkart.com/search?q={encoded}",
        "myntra": f"https://www.myntra.com/{encoded}"
    }


# ---------------- MAIN RECOMMENDATION ---------------- #

def recommend_buy_next(user, wardrobe):

    candidates = generate_candidate_items(user)

    current_outfits = count_outfits(
        wardrobe["tops"],
        wardrobe["bottoms"],
        wardrobe["shoes"]
    )

    results = []

    existing_colors = wardrobe_colors(wardrobe)

    for item in candidates:

        if item["color"] in existing_colors:
            continue

        new_outfits = simulate_item_gain(item, wardrobe)

        impact = new_outfits - current_outfits

        item_data = {
            "item": item,
            "impactScore": impact,
            "links": ecommerce_links(item)
        }

        results.append(item_data)

    results.sort(key=lambda x: x["impactScore"], reverse=True)

    return results[:5]


# ---------------- TEST ---------------- #

if __name__ == "__main__":

    user = {
        "skinTone": "warm"
    }

    wardrobe = {

        "tops":[
            {"id":"t1","type":"shirt","color":"navy"},
            {"id":"t2","type":"tshirt","color":"white"},
            {"id":"t3","type":"shirt","color":"maroon"}
        ],

        "bottoms":[
            {"id":"b1","type":"jeans","color":"black"},
            {"id":"b2","type":"chinos","color":"grey"}
        ],

        "shoes":[
            {"id":"s1","type":"sneaker","color":"white"},
            {"id":"s2","type":"loafer","color":"brown"}
        ]
    }

    recommendations = recommend_buy_next(user, wardrobe)

    print("\nRecommended Items To Buy:\n")

    for r in recommendations:

        item = r["item"]

        print("Item:", item["color"], item["type"])
        print("Impact Score:", r["impactScore"])

        print("Buy Links:")
        for site, link in r["links"].items():
            print(site, ":", link)

        print("\n")