# import itertools
# import json
# import os

# from rules import hard_filters
# from scoring import color_score,fit_score,occasion_score,history_penalty

# OCCASIONS = ["formal","semiFormal","casual","daily"]


# # ---------------- HISTORY ---------------- #

# def load_history():

#     if not os.path.exists("outfit_history.json"):
#         return []

#     with open("outfit_history.json","r") as f:
#         return json.load(f)


# def save_history(history):

#     with open("outfit_history.json","w") as f:
#         json.dump(history,f,indent=4)


# def store_outfit(results,history):

#     for occasion,data in results.items():

#         entry = {
#             "top":data["top"]["id"],
#             "bottom":data["bottom"]["id"],
#             "shoe":data["shoe"]["id"],
#             "occasion":occasion
#         }

#         history.append(entry)

#     save_history(history)


# # ---------------- OUTFIT GENERATION ---------------- #

# def generate_outfits(tops,bottoms,shoes):

#     outfits = []

#     for combo in itertools.product(tops,bottoms,shoes):

#         outfit = {
#             "top":combo[0],
#             "bottom":combo[1],
#             "shoe":combo[2]
#         }

#         if hard_filters(outfit):
#             outfits.append(outfit)

#     return outfits


# # ---------------- SCORING ---------------- #

# def score_outfit(outfit,user,occasion,history):

#     score = 0

#     score += color_score(outfit["top"]["color"],outfit["bottom"]["color"])
#     score += fit_score(outfit)
#     score += occasion_score(outfit,occasion)

#     score -= history_penalty(outfit,history)

#     return score


# # ---------------- RECOMMENDATION ---------------- #

# def recommend_outfits(user,wardrobe,history):

#     outfits = generate_outfits(
#         wardrobe["tops"],
#         wardrobe["bottoms"],
#         wardrobe["shoes"]
#     )

#     best_by_occasion = {}

#     for occasion in OCCASIONS:

#         best_score = -999
#         best_outfit = None

#         for outfit in outfits:

#             score = score_outfit(outfit,user,occasion,history)

#             if score > best_score:

#                 best_score = score
#                 best_outfit = outfit


#         best_by_occasion[occasion] = {

#             "top":{
#                 "id":best_outfit["top"]["id"],
#                 "type":best_outfit["top"]["type"],
#                 "color":best_outfit["top"]["color"],
#                 "fit":best_outfit["top"]["fit"]
#             },

#             "bottom":{
#                 "id":best_outfit["bottom"]["id"],
#                 "type":best_outfit["bottom"]["type"],
#                 "color":best_outfit["bottom"]["color"],
#                 "fit":best_outfit["bottom"]["fit"]
#             },

#             "shoe":{
#                 "id":best_outfit["shoe"]["id"],
#                 "type":best_outfit["shoe"]["type"],
#                 "color":best_outfit["shoe"]["color"]
#             },

#             "colorCombination":
#                 f"{best_outfit['top']['color']} + {best_outfit['bottom']['color']}",

#             "fitCombination":
#                 f"{best_outfit['top']['fit']} top with {best_outfit['bottom']['fit']} bottom",

#             "score":best_score
#         }

#     return best_by_occasion


# # ---------------- TEST ---------------- #

# if __name__ == "__main__":

#     user = {
#         "skinTone":"warm",
#         "bodyType":"rectangle"
#     }

#     wardrobe = {

#         "tops":[
#             {"id":"top1","type":"shirt","color":"navy","fit":"slim"},
#             {"id":"top2","type":"tshirt","color":"white","fit":"regular"},
#             {"id":"top3","type":"shirt","color":"maroon","fit":"slim"},
#             {"id":"top4","type":"shirt","color":"lightblue","fit":"regular"},
#             {"id":"top5","type":"tshirt","color":"olive","fit":"regular"}
#         ],

#         "bottoms":[
#             {"id":"bottom1","type":"formalPant","color":"grey","fit":"straight"},
#             {"id":"bottom2","type":"jeans","color":"blue","fit":"slim"},
#             {"id":"bottom3","type":"chinos","color":"beige","fit":"straight"},
#             {"id":"bottom4","type":"jeans","color":"black","fit":"slim"}
#         ],

#         "shoes":[
#             {"id":"shoe1","type":"oxford","color":"black"},
#             {"id":"shoe2","type":"loafer","color":"brown"},
#             {"id":"shoe3","type":"sneaker","color":"white"}
#         ]
#     }

#     history = load_history()

#     result = recommend_outfits(user,wardrobe,history)

#     print(json.dumps(result,indent=4))

#     store_outfit(result,history)






import itertools
import json
import os

from rules import hard_filters
from scoring import color_score, occasion_score, history_penalty


# occasions supported
OCCASIONS = ["formal", "semiFormal", "casual", "daily"]


# ---------------- HISTORY ---------------- #

HISTORY_FILE = "outfit_history.json"


def load_history():

    if not os.path.exists(HISTORY_FILE):
        return []

    with open(HISTORY_FILE, "r") as f:
        return json.load(f)


def save_history(history):

    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=4)


def store_outfit(results, history):

    for occasion, data in results.items():

        entry = {
            "top": str(data["top"]["id"]),
            "bottom": str(data["bottom"]["id"]),
            "shoe": str(data["shoe"]["id"]),
            "occasion": occasion
        }

        history.append(entry)

    save_history(history)


# ---------------- LAUNDRY FILTER ---------------- #

def filter_available(items):
    """
    Removes clothes that are currently in laundry
    """

    available_items = []

    for item in items:

        status = item.get("status", "available")

        if status == "available":
            available_items.append(item)

    return available_items


# ---------------- GENERATE OUTFITS ---------------- #

def generate_outfits(tops, bottoms, shoes):

    outfits = []

    for combo in itertools.product(tops, bottoms, shoes):

        outfit = {
            "top": combo[0],
            "bottom": combo[1],
            "shoe": combo[2]
        }

        # apply hard fashion rules
        if hard_filters(outfit):
            outfits.append(outfit)

    return outfits


# ---------------- SCORE OUTFIT ---------------- #

def score_outfit(outfit, user, occasion, history):

    score = 0

    # color compatibility
    score += color_score(
        outfit["top"]["color"],
        outfit["bottom"]["color"]
    )

    # occasion matching
    score += occasion_score(outfit, occasion)

    # avoid repeating outfits
    score -= history_penalty(outfit, history)

    return score


# ---------------- MAIN RECOMMENDATION ENGINE ---------------- #

def recommend_outfits(user, wardrobe):

    history = load_history()

    # remove clothes in laundry
    tops = filter_available(wardrobe.get("tops", []))
    bottoms = filter_available(wardrobe.get("bottoms", []))
    shoes = filter_available(wardrobe.get("shoes", []))

    # validate wardrobe
    if len(tops) == 0 or len(bottoms) == 0 or len(shoes) == 0:

        return {
            "success": False,
            "message": "Not enough available wardrobe items",
            "counts": {
                "tops": len(tops),
                "bottoms": len(bottoms),
                "shoes": len(shoes)
            },
            "outfits": []
        }

    # generate outfit combinations
    outfits = generate_outfits(tops, bottoms, shoes)

    if len(outfits) == 0:

        return {
            "success": False,
            "message": "No valid outfit combinations found",
            "outfits": []
        }

    best_by_occasion = {}

    # select best outfit for each occasion
    for occasion in OCCASIONS:

        best_score = -999
        best_outfit = None

        for outfit in outfits:

            score = score_outfit(outfit, user, occasion, history)

            if score > best_score:

                best_score = score
                best_outfit = outfit

        if best_outfit is None:
            continue

        best_by_occasion[occasion] = {

            "top": {
                "id": str(best_outfit["top"]["id"]),
                "type": best_outfit["top"]["type"],
                "color": best_outfit["top"]["color"],
                "imageUrl": best_outfit["top"]["imageUrl"]
            },

            "bottom": {
                "id": str(best_outfit["bottom"]["id"]),
                "type": best_outfit["bottom"]["type"],
                "color": best_outfit["bottom"]["color"],
                "imageUrl": best_outfit["bottom"]["imageUrl"]
            },

            "shoe": {
                "id": str(best_outfit["shoe"]["id"]),
                "type": best_outfit["shoe"]["type"],
                "color": best_outfit["shoe"]["color"],
                "imageUrl": best_outfit["shoe"]["imageUrl"]
            },

            "colorCombination":
                f"{best_outfit['top']['color']} + {best_outfit['bottom']['color']}",

            "score": best_score
        }

    # store history to avoid repetition
    store_outfit(best_by_occasion, history)

    return {
        "success": True,
        "outfits": best_by_occasion
    }


# ---------------- LOCAL TEST ---------------- #

if __name__ == "__main__":

    user = {
        "skinTone": "warm"
    }

    wardrobe = {

        "tops": [
            {
                "id": "1",
                "type": "Shirt",
                "color": "White",
                "imageUrl": "url1",
                "status": "available"
            },
            {
                "id": "2",
                "type": "Shirt",
                "color": "Maroon",
                "imageUrl": "url2",
                "status": "available"
            }
        ],

        "bottoms": [
            {
                "id": "3",
                "type": "Jeans",
                "color": "Blue",
                "imageUrl": "url3",
                "status": "available"
            },
            {
                "id": "4",
                "type": "Jeans",
                "color": "Black",
                "imageUrl": "url4",
                "status": "laundry"
            }
        ],

        "shoes": [
            {
                "id": "5",
                "type": "Shoes",
                "color": "Black",
                "imageUrl": "url5",
                "status": "available"
            }
        ]
    }

    result = recommend_outfits(user, wardrobe)

    print(json.dumps(result, indent=4))