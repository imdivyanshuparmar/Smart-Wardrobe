
import React, { useState } from 'react';
import { Button } from './Button';
import { Card } from './Card';
// Consolidate lucide-react imports and include Sparkles
import { Mail, Lock, User, ArrowRight, Sparkles } from 'lucide-react';

interface AuthPageProps {
  onSuccess: (name: string) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onSuccess }) => {
  const [name, setName] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name) onSuccess(name);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#fdf8ff]">
      {/* Left: Illustration Area */}
      <div className="hidden md:flex flex-1 items-center justify-center p-12 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="max-w-md text-center">
          <img 
            src="https://picsum.photos/seed/fashion/800/800" 
            alt="Fashion Illustration" 
            className="rounded-[3rem] shadow-2xl mb-8 transform -rotate-2 hover:rotate-0 transition-transform duration-500"
          />
          <h1 className="text-4xl font-display font-extrabold text-gray-900 mb-4">Elevate Your Style</h1>
          <p className="text-gray-600 text-lg">AI-powered personal stylist in your pocket. Designed for the modern trendsetter.</p>
        </div>
      </div>

      {/* Right: Form Area */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 text-center md:text-left">
            <div className="inline-block p-3 rounded-2xl bg-indigo-50 mb-4">
              <Sparkles className="w-8 h-8 text-indigo-500" />
            </div>
            <h2 className="text-3xl font-display font-bold text-gray-900 mb-2">Welcome Back</h2>
            <p className="text-gray-500">Let's get your outfit ready for the day.</p>
          </div>

          <Card className="mb-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-transparent rounded-2xl focus:bg-white focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 transition-all outline-none"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-transparent rounded-2xl focus:bg-white focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 transition-all outline-none"
                  required
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type="password" 
                  placeholder="Password" 
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-transparent rounded-2xl focus:bg-white focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 transition-all outline-none"
                  required
                />
              </div>
              <Button type="submit" fullWidth className="mt-2">
                Get Started <ArrowRight className="w-5 h-5" />
              </Button>
            </form>
          </Card>
          
          <div className="text-center">
            <p className="text-gray-500 text-sm">Don't have an account? <a href="#" className="text-indigo-600 font-semibold hover:underline">Sign Up</a></p>
          </div>
        </div>
      </div>
    </div>
  );
};
