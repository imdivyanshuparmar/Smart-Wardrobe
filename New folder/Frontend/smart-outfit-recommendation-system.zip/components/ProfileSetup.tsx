
import React, { useState } from 'react';
import { Button } from './Button';
import { Card } from './Card';
import { SKIN_TONES, BODY_FRAMES } from '../constants';
import { SkinTone, BodyFrame, UserProfile } from '../types';
import { ChevronRight, ChevronLeft, Ruler } from 'lucide-react';

interface ProfileSetupProps {
  userName: string;
  onComplete: (profile: UserProfile) => void;
}

export const ProfileSetup: React.FC<ProfileSetupProps> = ({ userName, onComplete }) => {
  const [step, setStep] = useState(1);
  const [skinTone, setSkinTone] = useState<SkinTone>('medium');
  const [height, setHeight] = useState(170);
  const [bodyFrame, setBodyFrame] = useState<BodyFrame>('average');

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else onComplete({ name: userName, skinTone, height, bodyFrame });
  };

  const handleBack = () => setStep(step - 1);

  return (
    <div className="max-w-2xl mx-auto py-12 px-6">
      <div className="mb-12 text-center">
        <div className="flex items-center justify-center gap-4 mb-6">
          {[1, 2, 3].map((s) => (
            <div 
              key={s}
              className={`h-2 rounded-full transition-all duration-500 ${step >= s ? 'w-12 bg-indigo-500' : 'w-4 bg-gray-200'}`}
            />
          ))}
        </div>
        <h1 className="text-3xl font-display font-bold text-gray-900">Personalize Your Fit</h1>
        <p className="text-gray-500">Help us understand your physique for better results.</p>
      </div>

      <div className="min-h-[400px]">
        {step === 1 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-xl font-semibold text-center text-gray-800">Select Skin Tone</h2>
            <div className="grid grid-cols-3 gap-6">
              {SKIN_TONES.map((tone) => (
                <button
                  key={tone.id}
                  onClick={() => setSkinTone(tone.id as SkinTone)}
                  className={`group relative flex flex-col items-center p-4 rounded-3xl transition-all duration-300 ${skinTone === tone.id ? 'bg-white shadow-xl ring-2 ring-indigo-500' : 'bg-gray-50 hover:bg-white'}`}
                >
                  <div 
                    className="w-16 h-16 rounded-2xl mb-3 shadow-inner"
                    style={{ backgroundColor: tone.color }}
                  />
                  <span className="font-medium text-gray-700">{tone.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-xl font-semibold text-center text-gray-800">What's Your Height?</h2>
            <Card className="text-center py-10">
              <div className="flex items-center justify-center gap-2 text-5xl font-display font-extrabold text-indigo-600 mb-8">
                {height} <span className="text-xl text-gray-400">cm</span>
              </div>
              <div className="relative px-4">
                <input 
                  type="range" 
                  min="140" 
                  max="210" 
                  value={height}
                  onChange={(e) => setHeight(parseInt(e.target.value))}
                  className="w-full h-3 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                />
                <div className="flex justify-between mt-4 text-sm text-gray-400">
                  <span>140cm</span>
                  <span>210cm</span>
                </div>
              </div>
            </Card>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-xl font-semibold text-center text-gray-800">Describe Your Build</h2>
            <div className="grid grid-cols-2 gap-4">
              {BODY_FRAMES.map((frame) => (
                <button
                  key={frame.id}
                  onClick={() => setBodyFrame(frame.id as BodyFrame)}
                  className={`flex items-center gap-4 p-6 rounded-3xl transition-all duration-300 ${bodyFrame === frame.id ? 'bg-indigo-500 text-white shadow-lg' : 'bg-white shadow-sm hover:shadow-md'}`}
                >
                  <div className={`p-3 rounded-2xl ${bodyFrame === frame.id ? 'bg-indigo-400' : 'bg-indigo-50 text-indigo-500'}`}>
                    {frame.icon}
                  </div>
                  <span className="font-bold text-lg">{frame.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-12 flex justify-between items-center">
        {step > 1 ? (
          <button onClick={handleBack} className="flex items-center gap-2 text-gray-500 font-semibold hover:text-gray-900 transition-colors">
            <ChevronLeft className="w-5 h-5" /> Back
          </button>
        ) : <div />}
        
        <Button onClick={handleNext}>
          {step === 3 ? 'Complete Setup' : 'Next Step'} <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};
