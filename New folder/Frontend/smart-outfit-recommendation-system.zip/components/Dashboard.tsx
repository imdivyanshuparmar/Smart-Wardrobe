
import React from 'react';
import { Button } from './Button';
import { Card } from './Card';
import { RecommendationResponse, UserProfile, ClothingItem } from '../types';
// Consolidate lucide-react imports and include Sparkles
import { RefreshCw, Star, Info, CheckCircle, Smartphone, MapPin, Box, Sparkles } from 'lucide-react';

interface DashboardProps {
  profile: UserProfile;
  recommendation: RecommendationResponse;
  items: ClothingItem[];
  onRetry: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ profile, recommendation, items, onRetry }) => {
  return (
    <div className="max-w-6xl mx-auto py-12 px-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Recommendation Card */}
        <div className="lg:col-span-2 space-y-8">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-4xl font-display font-extrabold text-gray-900 mb-2">{recommendation.outfitName}</h1>
              <p className="text-indigo-600 font-semibold flex items-center gap-2">
                <CheckCircle className="w-5 h-5" /> Best for {recommendation.occasionSuitability}
              </p>
            </div>
            <div className="bg-white px-6 py-4 rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Confidence</p>
                <p className="text-2xl font-display font-extrabold text-indigo-500">{recommendation.confidenceScore}%</p>
              </div>
              <div className="w-12 h-12 rounded-full border-4 border-indigo-100 border-t-indigo-500 rotate-45" />
            </div>
          </header>

          <Card className="relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
              <Sparkles className="w-64 h-64 text-indigo-500" />
            </div>
            <div className="relative z-10">
              <p className="text-xl text-gray-700 leading-relaxed mb-10">
                {recommendation.description}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Star className="w-4 h-4 text-amber-400" /> Style Tips
                  </h3>
                  <ul className="space-y-4">
                    {recommendation.styleTips.map((tip, i) => (
                      <li key={i} className="flex gap-4">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold">
                          {i + 1}
                        </span>
                        <p className="text-gray-600 text-sm font-medium">{tip}</p>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Recommended Palette</h3>
                  <div className="flex gap-3">
                    {recommendation.colorPalette.map((color, i) => (
                      <div key={i} className="flex flex-col items-center gap-2">
                        <div 
                          className="w-14 h-14 rounded-2xl shadow-sm border border-white"
                          style={{ backgroundColor: color }}
                        />
                        <span className="text-[10px] font-mono text-gray-400 uppercase">{color}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Future Feature Teaser */}
          <section className="mt-12">
            <h2 className="text-2xl font-display font-bold mb-6 flex items-center gap-3">
              Upcoming <span className="bg-indigo-100 text-indigo-600 text-xs px-3 py-1 rounded-full uppercase tracking-tighter">New Features</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-gradient-to-br from-indigo-50 to-white rounded-[2rem] border border-indigo-100">
                <div className="p-3 bg-indigo-500 text-white w-fit rounded-2xl mb-4">
                  <Smartphone className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">3D Avatar Preview</h3>
                <p className="text-sm text-gray-500">Virtually try on clothes using a digital twin built from your body frame profile.</p>
              </div>
              <div className="p-6 bg-gradient-to-br from-pink-50 to-white rounded-[2rem] border border-pink-100">
                <div className="p-3 bg-pink-500 text-white w-fit rounded-2xl mb-4">
                  <MapPin className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Occasion Scouting</h3>
                <p className="text-sm text-gray-500">Get location-aware styling based on local events and weather patterns.</p>
              </div>
            </div>
          </section>
        </div>

        {/* Sidebar: Current Items */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-display font-bold">Selected Items</h2>
            <button onClick={onRetry} className="text-indigo-600 hover:text-indigo-800 transition-colors p-2 bg-indigo-50 rounded-xl">
              <RefreshCw className="w-5 h-5" />
            </button>
          </div>
          <div className="space-y-6">
            {items.map((item, i) => (
              <div key={i} className="flex gap-4 group">
                <div className="w-24 h-32 rounded-3xl overflow-hidden shadow-md group-hover:scale-105 transition-transform duration-300">
                  <img src={item.image} alt={item.type} className="w-full h-full object-cover" />
                </div>
                <div className="flex flex-col justify-center">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{item.type}</span>
                  <p className="text-lg font-bold text-gray-800">Uploaded Item {i + 1}</p>
                  <p className="text-xs text-green-500 font-semibold flex items-center gap-1 mt-1">
                    <CheckCircle className="w-3 h-3" /> Scanned
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-8 rounded-[3rem] bg-gray-900 text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-500/20 to-transparent pointer-events-none" />
            <h3 className="text-xl font-display font-bold mb-4">Styling Profile</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">User</span>
                <span className="font-bold">{profile.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Height</span>
                <span className="font-bold">{profile.height} cm</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Build</span>
                <span className="font-bold capitalize">{profile.bodyFrame}</span>
              </div>
            </div>
            <Button variant="outline" className="mt-8 w-full border-gray-700 text-white hover:bg-gray-800">
              Edit Profile
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
