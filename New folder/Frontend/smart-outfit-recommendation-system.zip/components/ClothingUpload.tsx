
import React, { useState } from 'react';
import { Button } from './Button';
import { Card } from './Card';
import { ClothingItem } from '../types';
import { Upload, X, CheckCircle2, Shirt, Footprints, Layers, Sparkles } from 'lucide-react';

interface ClothingUploadProps {
  onComplete: (items: ClothingItem[]) => void;
}

export const ClothingUpload: React.FC<ClothingUploadProps> = ({ onComplete }) => {
  const [uploads, setUploads] = useState<{ [key: string]: string | null }>({
    shirt: null,
    jeans: null,
    shoes: null
  });
  const [scanning, setScanning] = useState(false);

  const handleFileChange = (type: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploads(prev => ({ ...prev, [type]: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeUpload = (type: string) => {
    setUploads(prev => ({ ...prev, [type]: null }));
  };

  const isComplete = !!(uploads.shirt && uploads.jeans && uploads.shoes);

  const startAnalysis = () => {
    setScanning(true);
    setTimeout(() => {
      const items: ClothingItem[] = Object.entries(uploads)
        .filter(([_, img]) => img !== null)
        .map(([type, img]) => ({ type: type as any, image: img! }));
      onComplete(items);
    }, 2500); // Visual scanning effect delay
  };

  const UploadSlot = ({ type, icon: Icon, label }: { type: string, icon: any, label: string }) => {
    const preview = uploads[type];
    
    return (
      <div className="flex flex-col gap-3">
        <label className="text-sm font-semibold text-gray-500 uppercase tracking-wider">{label}</label>
        <div className={`relative aspect-[3/4] rounded-[2.5rem] overflow-hidden group border-2 border-dashed transition-all duration-300 ${preview ? 'border-transparent shadow-2xl' : 'border-gray-200 hover:border-indigo-400 bg-white'}`}>
          {preview ? (
            <>
              <img src={preview} alt={type} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button 
                  onClick={() => removeUpload(type)}
                  className="p-3 bg-red-500 text-white rounded-full hover:scale-110 transition-transform"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              {scanning && <div className="scan-line" />}
            </>
          ) : (
            <label className="flex flex-col items-center justify-center w-full h-full cursor-pointer p-6">
              <div className="p-4 rounded-3xl bg-indigo-50 text-indigo-500 mb-4 group-hover:scale-110 transition-transform">
                <Icon className="w-8 h-8" />
              </div>
              <p className="text-gray-400 text-sm font-medium text-center">Drag or click to upload</p>
              <input 
                type="file" 
                className="hidden" 
                accept="image/*"
                onChange={(e) => handleFileChange(type, e)}
              />
            </label>
          )}
          {preview && !scanning && (
            <div className="absolute top-4 right-4 p-2 bg-green-500 text-white rounded-full">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-5xl mx-auto py-12 px-6">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-display font-extrabold text-gray-900 mb-4">Your Wardrobe</h1>
        <p className="text-gray-500 max-w-lg mx-auto">Upload clear photos of your pieces. AI works best with single-item photos on neutral backgrounds.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <UploadSlot type="shirt" icon={Shirt} label="Upper Body" />
        <UploadSlot type="jeans" icon={Layers} label="Lower Body" />
        <UploadSlot type="shoes" icon={Footprints} label="Footwear" />
      </div>

      <div className="mt-16 flex flex-col items-center gap-6">
        <Button 
          variant="primary" 
          disabled={!isComplete || scanning}
          onClick={startAnalysis}
          className={`h-16 px-12 text-lg ${scanning ? 'opacity-70' : ''}`}
        >
          {scanning ? (
            <>Analyzing Style... <Sparkles className="w-6 h-6 animate-pulse" /></>
          ) : (
            <>Generate Smart Outfit <Sparkles className="w-6 h-6" /></>
          )}
        </Button>
        <p className="text-sm text-gray-400 font-medium">
          {isComplete ? 'All set! Ready to process.' : 'Upload all 3 items to continue.'}
        </p>
      </div>
    </div>
  );
};
