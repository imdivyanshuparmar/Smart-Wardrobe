
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, ClothingItem, RecommendationResponse } from "../types";

export const getOutfitRecommendation = async (
  profile: UserProfile,
  items: ClothingItem[]
): Promise<RecommendationResponse> => {
  // Initialize GoogleGenAI with named apiKey parameter as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const imageParts = items.map(item => ({
    inlineData: {
      mimeType: "image/png",
      data: item.image.split(',')[1],
    }
  }));

  const prompt = `
    As a professional fashion stylist for college students and young professionals, analyze these ${items.length} clothing items.
    The user profile is:
    - Name: ${profile.name}
    - Skin Tone: ${profile.skinTone}
    - Height: ${profile.height}cm
    - Body Frame: ${profile.bodyFrame}
    
    Provide a detailed outfit recommendation that combines these items stylishly. 
    Explain why these work together based on the user's physical attributes.
  `;

  // Use 'gemini-3-flash-preview' for basic text and image tasks
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        ...imageParts,
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          outfitName: { type: Type.STRING },
          description: { type: Type.STRING },
          styleTips: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          colorPalette: { 
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Hex color codes representing the suggested palette"
          },
          confidenceScore: { 
            type: Type.NUMBER,
            description: "A score from 0 to 100 on how well the pieces match"
          },
          occasionSuitability: { type: Type.STRING }
        },
        required: ["outfitName", "description", "styleTips", "colorPalette", "confidenceScore", "occasionSuitability"]
      }
    }
  });

  // Accessing the .text property directly (not a method) as per guidelines
  const responseText = response.text || "";
  try {
    return JSON.parse(responseText.trim());
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Could not generate recommendation");
  }
};
