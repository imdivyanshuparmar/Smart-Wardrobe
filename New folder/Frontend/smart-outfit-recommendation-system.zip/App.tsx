
import React, { useState, useEffect } from 'react';
import { AuthPage } from './components/AuthPage';
import { ProfileSetup } from './components/ProfileSetup';
import { ClothingUpload } from './components/ClothingUpload';
import { Dashboard } from './components/Dashboard';
import { UserProfile, ClothingItem, RecommendationResponse, AppStep } from './types';
import { getOutfitRecommendation } from './services/geminiService';
// Consolidate lucide-react imports and include Sparkles
import { Shirt, LogOut, Menu, User, Bell, Smartphone, Box, Sparkles } from 'lucide-react';
import { NAV_LINKS } from './constants';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>('auth');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [clothingItems, setClothingItems] = useState<ClothingItem[]>([]);
  const [recommendation, setRecommendation] = useState<RecommendationResponse | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAuthSuccess = (name: string) => {
    // Initial partial profile
    setUserProfile({ name, skinTone: 'medium', height: 170, bodyFrame: 'average' });
    setStep('setup');
  };

  const handleProfileComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setStep('upload');
  };

  const handleUploadComplete = async (items: ClothingItem[]) => {
    setClothingItems(items);
    setLoading(true);
    try {
      if (userProfile) {
        const result = await getOutfitRecommendation(userProfile, items);
        setRecommendation(result);
        setStep('dashboard');
      }
    } catch (error) {
      alert("Failed to get recommendation. Please check your API key and try again.");
    } finally {
      setLoading(false);
    }
  };

  const renderNavbar = () => (
    <nav className="sticky top-0 z-50 glass border-b border-gray-100 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setStep('auth')}>
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-2 rounded-xl text-white">
            <Shirt className="w-6 h-6" />
          </div>
          <span className="text-xl font-display font-bold text-gray-900 hidden sm:inline-block">SmartOutfit</span>
        </div>
        
        {step !== 'auth' && (
          <div className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map(link => (
              <a key={link.name} href={link.path} className="text-sm font-semibold text-gray-500 hover:text-indigo-600 transition-colors">
                {link.name}
              </a>
            ))}
          </div>
        )}

        <div className="flex items-center gap-4">
          {step !== 'auth' && (
            <>
              <button className="p-2 text-gray-400 hover:text-indigo-600 relative">
                <Bell className="w-6 h-6" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-pink-500 rounded-full border-2 border-white" />
              </button>
              <button className="flex items-center gap-2 p-1 pl-3 pr-1 rounded-full bg-gray-50 border border-gray-100 hover:border-indigo-200 transition-all">
                <span className="text-sm font-bold text-gray-700 hidden sm:inline">{userProfile?.name?.split(' ')[0]}</span>
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <User className="w-5 h-5" />
                </div>
              </button>
            </>
          )}
          {step === 'auth' && (
             <button className="text-gray-900 p-2 md:hidden">
               <Menu className="w-6 h-6" />
             </button>
          )}
        </div>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen bg-white text-gray-900 selection:bg-indigo-100 selection:text-indigo-700">
      {renderNavbar()}
      
      <main>
        {loading && (
          <div className="fixed inset-0 z-[100] glass flex flex-col items-center justify-center gap-6 text-center px-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-full border-4 border-indigo-100 border-t-indigo-500 animate-spin" />
              {/* Correctly using Sparkles icon from lucide-react */}
              <Sparkles className="absolute inset-0 m-auto w-10 h-10 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl font-display font-bold text-gray-900">Consulting AI Stylist</h2>
              <p className="text-gray-500 max-w-xs mx-auto">Analyzing textures, colors, and your profile to curate the perfect look...</p>
            </div>
          </div>
        )}

        {step === 'auth' && <AuthPage onSuccess={handleAuthSuccess} />}
        {step === 'setup' && userProfile && (
          <ProfileSetup userName={userProfile.name} onComplete={handleProfileComplete} />
        )}
        {step === 'upload' && (
          <ClothingUpload onComplete={handleUploadComplete} />
        )}
        {step === 'dashboard' && recommendation && userProfile && (
          <Dashboard 
            profile={userProfile} 
            recommendation={recommendation} 
            items={clothingItems} 
            onRetry={() => setStep('upload')}
          />
        )}
      </main>

      {step !== 'auth' && (
        <footer className="mt-24 border-t border-gray-100 py-12 px-6">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-2">
              <div className="bg-gray-100 p-2 rounded-xl text-gray-400">
                <Shirt className="w-5 h-5" />
              </div>
              <span className="font-display font-bold text-gray-400">SmartOutfit</span>
            </div>
            <p className="text-gray-400 text-sm">© 2024 Smart Outfit Recommendation System. Built with Gemini AI.</p>
            <div className="flex gap-6">
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors"><Smartphone className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors"><Box className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors"><LogOut className="w-5 h-5" /></a>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
};

export default App;
