import itertools
import json
import os

from rules import hard_filters
from scoring import color_score,fit_score,occasion_score,history_penalty

OCCASIONS = ["formal","semiFormal","casual","daily"]


# ---------------- HISTORY ---------------- #

def load_history():

    if not os.path.exists("outfit_history.json"):
        return []

    with open("outfit_history.json","r") as f:
        return json.load(f)


def save_history(history):

    with open("outfit_history.json","w") as f:
        json.dump(history,f,indent=4)


def store_outfit(results,history):

    for occasion,data in results.items():

        entry = {
            "top":data["top"]["id"],
            "bottom":data["bottom"]["id"],
            "shoe":data["shoe"]["id"],
            "occasion":occasion
        }

        history.append(entry)

    save_history(history)


# ---------------- OUTFIT GENERATION ---------------- #

def generate_outfits(tops,bottoms,shoes):

    outfits = []

    for combo in itertools.product(tops,bottoms,shoes):

        outfit = {
            "top":combo[0],
            "bottom":combo[1],
            "shoe":combo[2]
        }

        if hard_filters(outfit):
            outfits.append(outfit)

    return outfits


# ---------------- SCORING ---------------- #

def score_outfit(outfit,user,occasion,history):

    score = 0

    score += color_score(outfit["top"]["color"],outfit["bottom"]["color"])
    score += fit_score(outfit)
    score += occasion_score(outfit,occasion)

    score -= history_penalty(outfit,history)

    return score


# ---------------- RECOMMENDATION ---------------- #

def recommend_outfits(user,wardrobe,history):

    outfits = generate_outfits(
        wardrobe["tops"],
        wardrobe["bottoms"],
        wardrobe["shoes"]
    )

    best_by_occasion = {}

    for occasion in OCCASIONS:

        best_score = -999
        best_outfit = None

        for outfit in outfits:

            score = score_outfit(outfit,user,occasion,history)

            if score > best_score:

                best_score = score
                best_outfit = outfit


        best_by_occasion[occasion] = {

            "top":{
                "id":best_outfit["top"]["id"],
                "type":best_outfit["top"]["type"],
                "color":best_outfit["top"]["color"],
                "fit":best_outfit["top"]["fit"]
            },

            "bottom":{
                "id":best_outfit["bottom"]["id"],
                "type":best_outfit["bottom"]["type"],
                "color":best_outfit["bottom"]["color"],
                "fit":best_outfit["bottom"]["fit"]
            },

            "shoe":{
                "id":best_outfit["shoe"]["id"],
                "type":best_outfit["shoe"]["type"],
                "color":best_outfit["shoe"]["color"]
            },

            "colorCombination":
                f"{best_outfit['top']['color']} + {best_outfit['bottom']['color']}",

            "fitCombination":
                f"{best_outfit['top']['fit']} top with {best_outfit['bottom']['fit']} bottom",

            "score":best_score
        }

    return best_by_occasion


# ---------------- TEST ---------------- #

if __name__ == "__main__":

    user = {
        "skinTone":"warm",
        "bodyType":"rectangle"
    }

    wardrobe = {

        "tops":[
            {"id":"top1","type":"shirt","color":"navy","fit":"slim"},
            {"id":"top2","type":"tshirt","color":"white","fit":"regular"},
            {"id":"top3","type":"shirt","color":"maroon","fit":"slim"},
            {"id":"top4","type":"shirt","color":"lightblue","fit":"regular"},
            {"id":"top5","type":"tshirt","color":"olive","fit":"regular"}
        ],

        "bottoms":[
            {"id":"bottom1","type":"formalPant","color":"grey","fit":"straight"},
            {"id":"bottom2","type":"jeans","color":"blue","fit":"slim"},
            {"id":"bottom3","type":"chinos","color":"beige","fit":"straight"},
            {"id":"bottom4","type":"jeans","color":"black","fit":"slim"}
        ],

        "shoes":[
            {"id":"shoe1","type":"oxford","color":"black"},
            {"id":"shoe2","type":"loafer","color":"brown"},
            {"id":"shoe3","type":"sneaker","color":"white"}
        ]
    }

    history = load_history()

    result = recommend_outfits(user,wardrobe,history)

    print(json.dumps(result,indent=4))

    store_outfit(result,history)